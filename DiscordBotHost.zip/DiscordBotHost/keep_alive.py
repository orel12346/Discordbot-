import os
import time
import subprocess
import threading
import flask
from flask import Flask, jsonify
from datetime import datetime

# Create a Flask web server
app = Flask(__name__)

# Store the time when the server started
start_time = datetime.utcnow()

# Store status of discord bot
discord_bot_status = {
    "running": False,
    "last_check": start_time,
    "restart_count": 0,
    "last_restart": None
}

def restart_discord_bot():
    """Function to restart the Discord bot workflow"""
    try:
        # Try to restart the discord_bot workflow
        subprocess.run(["replit", "wf", "restart", "discord_bot"], 
                    check=True, capture_output=True)
        discord_bot_status["restart_count"] += 1
        discord_bot_status["last_restart"] = datetime.utcnow()
        print(f"Restarted Discord bot at {discord_bot_status['last_restart']}")
        discord_bot_status["running"] = True
        return True
    except Exception as e:
        print(f"Failed to restart Discord bot: {e}")
        return False

def check_discord_bot_status():
    """Check if the Discord bot is running and restart if needed"""
    while True:
        try:
            # Update last check time
            discord_bot_status["last_check"] = datetime.utcnow()
            
            # Check if bot workflow is running
            result = subprocess.run(["replit", "wf", "status", "discord_bot"], 
                                capture_output=True, text=True)
            
            if "running" not in result.stdout.lower():
                print("Discord bot is not running. Restarting...")
                restart_discord_bot()
            else:
                discord_bot_status["running"] = True
                
        except Exception as e:
            print(f"Error checking Discord bot status: {e}")
            
        # Sleep for 5 minutes (300 seconds) before checking again
        time.sleep(300)

@app.route('/')
def home():
    """Main endpoint for UptimeRobot to ping"""
    # Calculate uptime
    uptime = datetime.utcnow() - start_time
    uptime_hours = divmod(uptime.total_seconds(), 3600)[0]
    uptime_minutes = divmod(uptime.total_seconds(), 60)[0]
    
    # Return status information
    return jsonify({
        "status": "online",
        "server_time": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
        "uptime": f"{int(uptime_hours)}h {int(uptime_minutes % 60)}m",
        "discord_bot": {
            "status": "running" if discord_bot_status["running"] else "restarting",
            "last_check": discord_bot_status["last_check"].strftime("%Y-%m-%d %H:%M:%S UTC"),
            "restart_count": discord_bot_status["restart_count"],
            "last_restart": discord_bot_status["last_restart"].strftime("%Y-%m-%d %H:%M:%S UTC") if discord_bot_status["last_restart"] else None
        }
    })

@app.route('/restart-bot')
def restart_bot_endpoint():
    """Endpoint to manually trigger a bot restart"""
    success = restart_discord_bot()
    return jsonify({
        "success": success,
        "message": "Discord bot restart initiated" if success else "Failed to restart Discord bot",
        "time": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    })

def run_flask():
    """Run the Flask application"""
    app.run(host='0.0.0.0', port=5000)

if __name__ == "__main__":
    # Start the bot status monitoring thread
    monitor_thread = threading.Thread(target=check_discord_bot_status, daemon=True)
    monitor_thread.start()
    
    # Start the Flask web server
    run_flask()